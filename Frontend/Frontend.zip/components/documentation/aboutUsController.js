'use strict';

mixTapeApp.controller('AboutUsController', ['$scope', '$routeParams',
  function ($scope, $routeParams) {

  }]);
